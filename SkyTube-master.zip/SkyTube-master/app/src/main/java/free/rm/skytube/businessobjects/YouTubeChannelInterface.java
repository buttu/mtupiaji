package free.rm.skytube.businessobjects;

public interface YouTubeChannelInterface {
	void onGetYouTubeChannel(YouTubeChannel youTubeChannel);
}
